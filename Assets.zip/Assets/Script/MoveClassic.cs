using System.Collections;
using System.Collections.Generic;
using System.Xml.Schema;
using UnityEngine;

public class MoveClassic : MonoBehaviour
{
    
    public float speed = 0.5f;

    public int wall = 1;
    
    private Vector2 dest;
    private void Start()
    {
        
        dest = transform.position;
    }




    private void FixedUpdate()
    {


        
        Vector2 temp = Vector2.MoveTowards(transform.position, dest, speed);
        
        GetComponent<Rigidbody2D>().MovePosition(temp);
        

        //if ((Vector2) transform.position == dest)
        {
            Debug.DrawLine((transform.position + new Vector3(1, 0, 0)), transform.position, Color.red);

            if ((Input.GetKey(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W)) && Valid(new Vector2(0, (float)1.06)))
            {

                CancelInvoke();


                InvokeRepeating("Up", 0, 0.04f);


            }
            if ((Input.GetKey(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) && Valid(new Vector2(0, -(float)1.06)))
            {

                CancelInvoke();

                InvokeRepeating("Down", 0, 0.04f);



            }
            if ((Input.GetKey(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) && Valid(new Vector2(-(float)1.06, 0)))
            {

                CancelInvoke();

                InvokeRepeating("Left", 0, 0.04f);
            }
            if ((Input.GetKey(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) && Valid(new Vector2((float)1.06, 0)))
            {

                CancelInvoke();

                InvokeRepeating("Right", 0, 0.04f);
            }

        }

        
        //Vector2 dir = dest - (Vector2)transform.position;
        
        //GetComponent<Animator>().SetFloat("DirX", dir.x);
        //GetComponent<Animator>().SetFloat("DirY", dir.y);
    }



    private bool Valid(Vector2 dir)
    {
        
        Vector2 pos = transform.position;
        
        RaycastHit2D hit = Physics2D.Linecast(pos + dir, pos);
        
        return (hit.collider == GetComponent<Collider2D>());

    }

    private void Up()
    {

        if (Valid(new Vector2(0, (float)1.06)))
        {
            speed = 0.5f;
            dest = (Vector2)transform.position + new Vector2(0, (float)0.5);
            GetComponent<Animator>().SetFloat("DirX", 0);
            GetComponent<Animator>().SetFloat("DirY", 1);
        }

    }
    private void Down()
    {

        if (Valid(new Vector2(0, -(float)1.06)))
        {
            speed = 0.5f;
            dest = (Vector2)transform.position + new Vector2(0, -(float)0.5);
            GetComponent<Animator>().SetFloat("DirX", 0);
            GetComponent<Animator>().SetFloat("DirY", -1);
        }

    }
    private void Left()
    {

        if (Valid(new Vector2(-(float)1.06, 0)))
        {
            speed = 0.5f;
            dest = (Vector2)transform.position + new Vector2(-(float)0.5, 0);
            GetComponent<Animator>().SetFloat("DirX", -1);
            GetComponent<Animator>().SetFloat("DirY", 0);
        }

    }
    private void Right()
    {

        if (Valid(new Vector2((float)1.06, 0)))
        {
            speed = 0.5f;
            dest = (Vector2)transform.position + new Vector2((float)0.5, 0);
            GetComponent<Animator>().SetFloat("DirX", 1);
            GetComponent<Animator>().SetFloat("DirY", 0);
        }


    }
}
