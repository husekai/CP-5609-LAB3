using System.Threading;
using UnityEngine;



public class PacmanMove : MonoBehaviour
{
    
    public float speed = 0.5f;
    
    private Vector2 dest = Vector2.zero;

    private void Start()
    {
        
        dest = transform.position;
    }



    private void FixedUpdate()
    {

        
        Vector2 temp = Vector2.MoveTowards(transform.position, dest, speed);
        
        GetComponent<Rigidbody2D>().MovePosition(temp);
        
        //if ((Vector2)transform.position == dest)
        {
            Debug.DrawLine(dest, transform.position, Color.red);
            if ((Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W)) && Valid(new Vector2(0, (float)1.06)))
            {


                dest = (Vector2)transform.position + new Vector2(0, (float)0.5);
                GetComponent<Animator>().SetFloat("DirX", 0);
                GetComponent<Animator>().SetFloat("DirY", 1);


            }
            if ((Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S)) && Valid(new Vector2(0, -(float)1.06)))
            {
                dest = (Vector2)transform.position + new Vector2(0, -(float)0.5);
                GetComponent<Animator>().SetFloat("DirX", 0);
                GetComponent<Animator>().SetFloat("DirY", -1);
            }
            if ((Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) && Valid(new Vector2(-(float)1.06, 0)))
            {
                dest = (Vector2)transform.position + new Vector2(-(float)0.5, 0);
                GetComponent<Animator>().SetFloat("DirX", -1);
                GetComponent<Animator>().SetFloat("DirY", 0);
            }
            if ((Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) && Valid(new Vector2((float)1.06, 0)))
            {
                dest = (Vector2)transform.position + new Vector2((float)0.5, 0);
                GetComponent<Animator>().SetFloat("DirX", 1);
                GetComponent<Animator>().SetFloat("DirY", 0);
            }
            
            //Vector2 dir = dest - (Vector2)transform.position;
            
            //GetComponent<Animator>().SetFloat("DirX", dir.x);
            //GetComponent<Animator>().SetFloat("DirY", dir.y);
        }

    }

    private bool Valid(Vector2 dir)
    {
        
        Vector2 pos = transform.position;
        
        RaycastHit2D hit = Physics2D.Linecast(pos + dir, pos);
        
        return (hit.collider == GetComponent<Collider2D>());
    }
}

